// adding a new bookmark row to the popup
document.addEventListener("DOMContentLoaded", () => {});
